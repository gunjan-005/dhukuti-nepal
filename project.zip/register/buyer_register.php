<?php
$conn = mysqli_connect('localhost', 'root', '', 'dhukuti_nepal');

if (isset($_POST['buyer-register'])) {
    // Get form inputs
    $fullname = trim($_POST['fullname']);
    $parts = explode(" ", $fullname);
    $fname = array_shift($parts);            
    $lname = implode(" ", $parts);           

    $email = $_POST['email'];
    $contact = $_POST['contact_number'];
    $esewa = $_POST['esewa_account'];

    $password = $_POST['password'];
    $cpassword = $_POST['cpassword'];

    if ($password === $cpassword && preg_match('/^[A-Za-z ]+$/', $fullname)) {
        $hashed_pass = password_hash($password, PASSWORD_DEFAULT);

        $check_sql = "SELECT * FROM dhukuti_buyer WHERE email='$email'";
        $result = mysqli_query($conn, $check_sql);

        if ($result && $result->num_rows == 0) {
            $insert_sql = "INSERT INTO dhukuti_buyer 
                (first_name, last_name, email, password, contact_number, esewa_account) 
                VALUES 
                ('$fname', '$lname', '$email', '$hashed_pass', '$contact', '$esewa')";

            if (mysqli_query($conn, $insert_sql)) {
                header("Location: ../login.php");
                exit();
            } else {
                echo "Something went wrong while saving your data.";
            }
        } else {
            echo "This email is already registered.";
        }
    } else {
        echo "Passwords do not match or name is invalid.";
    }
}

mysqli_close($conn);
?>
