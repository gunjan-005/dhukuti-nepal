<?php
// index.php - Home page for Dhukuti Nepal
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dhukuti Nepal</title>
    <link rel="stylesheet" href="style.css"> <!-- Optional external stylesheet -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:RGB(244, 201, 141);
            padding: 30px;
            text-align: center;
        }

        h1 {
            color:rgb(80, 44, 44);
        }

        .nav-links a {
            display: inline-block;
            margin: 10px;
            padding: 10px 20px;
            background-color:#AE7627;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }

        .nav-links a:hover {
            background-color:#AE7627;
            opacity: 0.5;
        }
    </style>
</head>
<body>

    <h1>Welcome to Dhukuti Nepal</h1>
    <p>Nepali Sipkala ko digital Khajana</p>
    <p> Please register or log in </p>

    <div class="nav-links">
        <a href="buyer_register.php">Buyer Registration</a>
        <a href="seller_register.php">Seller Registration</a>
        <a href="login.php">Login</a>
        <!-- Add more links as needed -->
    </div>

</body>
</html>
